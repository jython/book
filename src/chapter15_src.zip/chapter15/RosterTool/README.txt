This file is for you to describe the RosterTool application. Typically
you would include information such as the information below:

Installation and Setup
======================

Install ``RosterTool`` using easy_install::

    easy_install RosterTool

Make a config file as follows::

    paster make-config RosterTool config.ini

Tweak the config file as appropriate and then setup the application::

    paster setup-app config.ini

Then you are ready to go.
